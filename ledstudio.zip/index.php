<!DOCTYPE html>
<html lang="zxx">

<head><meta charset="euc-kr">
	<title>Led Studio - Home</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<meta name="keywords" content="Inside Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css?vs=3" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext"
	 rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	 rel="stylesheet">
	<!-- //Web-Fonts -->
	<script src="js/jssor.slider-28.0.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        window.jssor_1_slider_init = function() {

            var jssor_1_SlideoTransitions = [
              [{b:-1,d:1,ls:0.5},{b:0,d:1000,y:5,e:{y:6}}],
              [{b:-1,d:1,ls:0.5},{b:200,d:1000,y:25,e:{y:6}}],
              [{b:-1,d:1,ls:0.5},{b:400,d:1000,y:45,e:{y:6}}],
              [{b:-1,d:1,ls:0.5},{b:600,d:1000,y:65,e:{y:6}}],
              [{b:-1,d:1,ls:0.5},{b:800,d:1000,y:85,e:{y:6}}],
              [{b:-1,d:1,ls:0.5},{b:500,d:1000,y:195,e:{y:6}}],
              [{b:0,d:2000,y:30,e:{y:3}}],
              [{b:-1,d:1,rY:-15,tZ:100},{b:0,d:1500,y:30,o:1,e:{y:3}}],
              [{b:-1,d:1,rY:-15,tZ:-100},{b:0,d:1500,y:100,o:0.8,e:{y:3}}],
              [{b:500,d:1500,o:1}],
              [{b:0,d:1000,y:380,e:{y:6}}],
              [{b:300,d:1000,x:80,e:{x:6}}],
              [{b:300,d:1000,x:330,e:{x:6}}],
              [{b:-1,d:1,r:-110,sX:5,sY:5},{b:0,d:2000,o:1,r:-20,sX:1,sY:1,e:{o:6,r:6,sX:6,sY:6}}],
              [{b:0,d:600,x:150,o:0.5,e:{x:6}}],
              [{b:0,d:600,x:1140,o:0.6,e:{x:6}}],
              [{b:-1,d:1,sX:5,sY:5},{b:600,d:600,o:1,sX:1,sY:1,e:{sX:3,sY:3}}]
            ];

            var jssor_1_options = {
              $AutoPlay: 1,
              $LazyLoading: 1,
              $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: jssor_1_SlideoTransitions
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$,
                $SpacingX: 20,
                $SpacingY: 20
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 3000;

            function ScaleSlider() {
                var containerElement = jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    jssor_1_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
    </script>
    <link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,300italic,regular,italic,700,700italic&subset=latin-ext,greek-ext,cyrillic-ext,greek,vietnamese,latin,cyrillic" rel="stylesheet" type="text/css" />
    <style>
        /* jssor slider loading skin spin css */
        .animation-wrapper {
              width: 80%;
              padding-bottom: 45%;
            }
            
            /** Layered Animation **/
            
            .layered-animations {
              position: absolute;
              top: 50%;
              left: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              width: 1100px;
              height: 550px;
              margin: -275px 0 0 -550px;
            }
            
            .layered-animations .shape {
              position: absolute;
              top: 50%;
              overflow: visible;
              width: 280px;
              height: 280px;
              margin-top: -140px;
              stroke: transparent;
              stroke-width: 1px;
              fill: url(#shapesGradient);
            }
            
            @media (min-width: 740px) {
              .layered-animations .shape {
                stroke-width: .5px;
              }
            }
            
            .layered-animations .small.shape {
              width: 64px;
              height: 64px;
              margin-top: -32px;
              stroke: currentColor;
              fill: currentColor;
            }
            
            .layered-animations .x-small.shape {
              width: 32px;
              height: 32px;
              margin-top: -16px;
              stroke: currentColor;
              fill: currentColor;
            }
        .jssorl-009-spin img {
            animation-name: jssorl-009-spin;
            animation-duration: 1.6s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        }

        @keyframes jssorl-009-spin {
            from {
                transform: rotate(0deg);
            }

            to {
                transform: rotate(360deg);
            }
        }


        /*jssor slider bullet skin 132 css*/
        .jssorb132 {position:absolute;}
        .jssorb132 .i {position:absolute;cursor:pointer;}
        .jssorb132 .i .b {fill:#fff;fill-opacity:0.8;stroke:#000;stroke-width:1600;stroke-miterlimit:10;stroke-opacity:0.7;}
        .jssorb132 .i:hover .b {fill:#000;fill-opacity:.7;stroke:#fff;stroke-width:2000;stroke-opacity:0.8;}
        .jssorb132 .iav .b {fill:#000;stroke:#fff;stroke-width:2400;fill-opacity:0.8;stroke-opacity:1;}
        .jssorb132 .i.idn {opacity:0.3;}

        .jssora051 {display:block;position:absolute;cursor:pointer;}
        .jssora051 .a {fill:none;stroke:#fff;stroke-width:360;stroke-miterlimit:10;}
        .jssora051:hover {opacity:.8;}
        .jssora051.jssora051dn {opacity:.5;}
        .jssora051.jssora051ds {opacity:.3;pointer-events:none;}
    </style>
</head>

<body>
	<!-- header -->
<?php include 'header.php'; ?>
	<!-- //header -->

	<!-- banner -->
	<!--<div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:1600px;height:750px;overflow:hidden;visibility:hidden;">
        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:1600px;height:750px;overflow:hidden;">
            <div>
                <img data-u="image" data-src="images/light-mirror.webp"/>
            </div>
            <div>
                <img data-u="image" data-src="images/bg.jpg" />
            </div>
            <div>
                <img data-u="image" data-src="images/sanitising.jpg" />
            </div>
            <div>
                <img data-u="image" data-src="images/light-slider.webp" />
            </div>
            <div>
                <img data-u="image" data-src="images/light-slider2.webp" />
            </div>
            <div>
                <img data-u="image" data-src="images/lightslider3.webp" />
            </div>
        </div><a data-scale="0" href="https://www.jssor.com" style="display:none;position:absolute;">slider html</a>
        <div data-u="navigator" class="jssorb132" style="position:absolute;bottom:24px;right:16px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:12px;height:12px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                </svg>
            </div>
        </div>
        <div data-u="arrowleft" class="jssora051" style="width:55px;height:55px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora051" style="width:55px;height:55px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
            </svg>
        </div>
    </div>--->
    <div class="animation-wrapper">
      <div class="layered-animations">
        <svg class="large shape" viewBox="0 0 96 96">
          <defs>
            <linearGradient id="circleGradient" x1="0%" x2="100%" y1="20%" y2="80%">
              <stop stop-color="#D10A28" offset="0%"/>
              <stop stop-color="#D10A28" offset="50%"/>
              <stop stop-color="#D10A28" offset="100%"/>
            </linearGradient>
          </defs>
          <circle cx="48" cy="48" r="28" fill-rule="evenodd" stroke-linecap="square" fill="url(#circleGradient)"/>
        </svg>
        <svg class="small shape color-white" viewBox="0 0 96 96" style="color:white;">
          <polygon fill-rule="evenodd" points="48 17.28 86.4 80.11584 9.6 80.11584" stroke-linecap="square"/>
        </svg>
        <svg class="large shape" viewBox="0 0 96 96">
          <defs>
            <linearGradient id="triangleGradient" x1="0%" x2="100%" y1="20%" y2="80%">
              <stop stop-color="white" offset="0%"/>
              <stop stop-color="white" offset="50%"/>
              <stop stop-color="white" offset="100%"/>
            </linearGradient>
          </defs>
          <polygon fill-rule="evenodd" points="48 17.28 86.4 80.11584 9.6 80.11584" stroke-linecap="square" fill="url(#triangleGradient)"/>
        </svg>
        <svg class="x-small shape" viewBox="0 0 96 96" style="color:white;">
          <polygon fill-rule="evenodd" points="48 17.28 86.4 80.11584 9.6 80.11584" stroke-linecap="square"/>
        </svg>
        <svg class="x-small shape" viewBox="0 0 96 96" style="color:#C7C7CF;">
          <rect width="48" height="48" x="24" y="24" fill-rule="evenodd" stroke-linecap="square"/>
        </svg>
        <svg class="small shape color-red" viewBox="0 0 96 96" style="color:#C7C7CF;">
          <rect width="48" height="48" x="24" y="24" fill-rule="evenodd" stroke-linecap="square"/>
        </svg>
        <svg class="large shape" viewBox="0 0 96 96">
          <defs>
            <linearGradient id="rectGradient" x1="0%" x2="100%" y1="20%" y2="80%">
              <stop stop-color="#C7C7CF" offset="0%"/>
              <stop stop-color="#C7C7CF" offset="50%"/>
              <stop stop-color="#C7C7CF" offset="100%"/>
            </linearGradient>
          </defs>
          <rect width="48" height="48" x="24" y="24" fill-rule="evenodd" stroke-linecap="square" fill="url(#rectGradient)"/>
        </svg>
        <svg class="small shape color-red" viewBox="0 0 96 96" style="color:#D10A28;">
          <circle cx="48" cy="48" r="32" fill-rule="evenodd" stroke-linecap="square"/>
        </svg>
        <svg class="x-small shape" viewBox="0 0 96 96" style="color:#D10A28;">
          <circle cx="48" cy="48" r="32" fill-rule="evenodd" stroke-linecap="square"/>
        </svg>
      </div>
    </div>
	<div class="main-w3pvt">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-7 style-banner">
					<h1 class="font-weight-bold text-white">Creating <span>better</span>  solutions together </h1>
					<p class="mt-5 text-white">Hafele is an international company providing hardware and fitting systems and electronic access control systems.</p>
					<a href="contact.php" class="btn button-style mt-sm-5 mt-4">Contact Us</a>
				</div>
				<div class="col-lg-5 banner-img">

				</div>
			</div>
		</div>
	</div>
	<!-- middle section -->
	<div class="middle-w3l pb-5" id="some">
		<div class=" pb-xl-5 pb-lg-3">
			<div class="">
				<div class="left-build-wthree">
					<h2 class="middle-title-w3 font-weight-bold text-white">Aquasys Light Mirror</h2>
					<h6 class="mt-5 text-white">Give your designs the perfect touch in the bath, vanity or closet areas with Häfele’s range of Aquasys Light Mirrors. Beautifully designed, the mirror adds value, functionality and style to any interior space.</h6>
					<p class="mt-2 text-white">The versatile mirror comes fully assembled and unites the functions of make-up lighting, room lighting, mood lighting, demister (prevents condensation on the mirror during and after a shower) and sound system in an elegant design.</p>
					<a href="AquasysLightMirror.php" class="btn button-style mt-sm-5">Read More</a>
				</div>
				<div class="right-side-img-w3 mt-5" style="background: url(../images/light-mirror.webp) no-repeat;">

				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //middle section -->
	<!-- middle section 1 -->
	<div class="container-fluid">
		<div class="row mt-5 mb-5">
			<div class="col-md-7">
				<img src="images/bg.jpg" class="img-responsive" style="width: 100%; border-radius: 0px 200px 200px 0px;">
			</div>
			<div class="left-build-wthree col-md-5">
				<h2 class="middle-title-w3 font-weight-bold text-white">LED Lighting System</h2>
				<h6 class="mt-5 text-white">Lights that set the mood, enhance the ambience & a life time! Our range of LED & CFL lighting solutions provide functionality for every application.</h6>
				<p class="mt-2 text-white">The planning of light in furniture and furnishings puts a multitude of demands on architects, electricians, contractors and finishers, and even developers and operators...</p>
				
				<a href="led-lighting-system.php" class="btn button-style mt-sm-5">Read More</a>

			</div>
		</div>
	</div>
	<!-- //middle section 1 -->
	<!-- middle section -->
	<div class="middle-w3l pb-5" id="some">
		<div class=" pb-xl-5 pb-lg-3">
			<div class="">
				<div class="left-build-wthree">
					<h2 class="middle-title-w3 font-weight-bold text-white">Sanitising Station</h2>
					<h6 class="mt-5 text-white">When it comes to bathrooms, it goes a step beyond mere hygiene. Hafele can help you with some exceptional ideas to meet every such need.</h6>
					<p class="mt-2 text-white">Conforming to how the Indian Industry works where typical sanitary retailers also sell sink units and faucets for kitchens, Hafele has clubbed all products for Kitchen Sink units and Bathroom fittings under its Sanitary Solutions Range...</p>
					
					<a href="sanitising-stations.php" class="btn button-style mt-sm-5">Read More</a>
				</div>
				<div class="right-side-img-w3 mt-5">

				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!-- //middle section -->
	<!-- middle section 2 -->
	<div class="some-another text-center py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="grid-single bg-white p-sm-5 p-3">
				<h3 class="title-w3 title-w3-2 mb-sm-5 mb-4 text-dark text-center font-weight-bold">We are here</h3>
				<p class="mb-4 mt-2">'LED STUDIO is the largest H'A'FELE distributor & prime Stockist in the entire North East & Eastern India. We deal with 'HAFELE Lightings' , 'LOOX5' , 'AQUASYS LIGHT MIRROR' & 'SANITIZATION'.</p>
				<a href="contact.php" class="btn button-style mt-sm-4 mt-3">Write to Us</a>

			</div>
		</div>
	</div>
	<!-- //middle section 2 -->

	<!-- ways -->
	<!---<div class="blog-w3ls py-5 bg-light" id="blog">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3 mb-sm-5 mb-4 text-dark text-center font-weight-bold">Our Blog</h3>
			<p class="title-para text-center mx-auto mb-sm-5 mb-4">Ut enim ad minim veniam, quis nostrud exercitation ullamco
				laboris nisi ut aliquip ex ea commodo consequat, dolor sit amet consectetur elit.</p>
			<div class="row package-grids">
				<div class="col-md-4 blog-w3">
					<div class="blogs-top">
						<a href="single.html">
							<img src="images/blog1.jpg" alt="" class="img-fluid" />
						</a>
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark mb-3">Sit voluptatem accusantium doloremque</h4>
						<h3 class="my-3">18 Sep 2018</h3>
						<a href="single.html">
							<i class="fa fa-user mr-2"></i>Posted by accusantium</a>
					</div>
				</div>
				<div class="col-md-4 blog-w3 my-md-0 my-5">
					<div class="blogs-top">
						<a href="single.html">
							<img src="images/blog2.jpg" alt="" class="img-fluid" />
						</a>
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark mb-3">Sit voluptatem accusantium doloremque</h4>
						<h3 class="my-3">21 Sep 2018</h3>
						<a href="single.html">
							<i class="fa fa-user mr-2"></i>Posted by accusantium</a>
					</div>
				</div>
				<div class="col-md-4 blog-w3">
					<div class="blogs-top">
						<a href="single.html">
							<img src="images/blog3.jpg" alt="" class="img-fluid" />
						</a>
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark">Sit voluptatem accusantium doloremque</h4>
						<h3 class="my-3">30 Sep 2018</h3>
						<a href="single.html">
							<i class="fa fa-user mr-2"></i>Posted by accusantium</a>
					</div>
				</div>
			</div>
			<div class="text-center">
				<a href="blog.html" class="btn button-style mt-sm-5 mt-4">Read More</a>
			</div>
		</div>
	</div>--->
	 <!-- Modal Form-->
    <div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
		<h1 class="mb-4 text-capitalize text-dark">Write to Us</h1>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <div class="contact-top1">
				<form action="#" method="get" class="contact-wthree">
					<div class="form-group d-flex">
						<label>
							<i class="fa fa-user" aria-hidden="true"></i>
						</label>
						<input class="form-control" type="name" id="name" placeholder="Enter your name..." name="name" required="">
					</div>
					<div class="form-group d-flex">
						<label>
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</label>
						<input class="form-control" type="email" id="email" placeholder="Enter your email..." name="email" required="">
					</div>
					<div class="form-group d-flex">
						<label>
							<i class="fa fa-phone" aria-hidden="true"></i>
						</label>
						<input class="form-control" type="number" id="mobile" placeholder="Enter your Phone Number..." name="mobile" required="">
					</div>
					<div class="form-group d-flex">
						<label>
							<i class="fa fa-edit"></i>
						</label>
						<input class="form-control" type="text" id="subject" placeholder="Subject" name="subject" required="">
					</div>
					<div class="form-group">
						<textarea class="form-control" rows="5" id="message" placeholder="Your message" name="message" required></textarea>
					</div>
					<div class="d-flex  justify-content-end">
						<button type="submit" id="send_mail" class="btn text-white btn-block w-25">Submit</button>
					</div>
				</form>
            </div>
        </div>
        
      </div>
    </div>
  </div>

    <!-- Modal Form-->

	<!-- footer -->
	<?php include 'footer.php'; ?>


	<!-- Js files -->
	<!-- JavaScript -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- Default-JavaScript-File -->
	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!-- fixed navigation -->
	<script src="js/fixed-nav.js"></script>
	<!-- //fixed navigation -->
	<!-- dropdown smooth -->
	<script>
		$(document).ready(function () {
				$(".dropdown").hover(
					function () {
						$('.dropdown-menu', this).stop(true, true).slideDown("fast");
						$(this).toggleClass('open');
					},
					function () {
						$('.dropdown-menu', this).stop(true, true).slideUp("fast");
						$(this).toggleClass('open');
					}
				);
			});
		</script>
	<!-- //dropdown smooth -->

	<!-- search plugin -->
	<!-- pop-up-box -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/jquery.magnific-popup.js"></script>
	<!-- //pop-up-box -->
	<!-- search script -->
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
	<!-- //search script -->
	<!-- //search plugin -->

	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- move-top -->
	<script src="js/move-top.js"></script>
	<!-- easing -->
	<script src="js/easing.js"></script>
	<!--  necessary snippets for few javascript files -->
	<script src="js/inside.js"></script>

	<script src="js/bootstrap.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //Js files -->
<script type="text/javascript">jssor_1_slider_init();
    </script>
    <script>
        function fitElementToParent(el, padding) {
          var timeout = null;
          function resize() {
            if (timeout) clearTimeout(timeout);
            anime.set(el, {scale: 1});
            var pad = padding || 0;
            var parentEl = el.parentNode;
            var elOffsetWidth = el.offsetWidth - pad;
            var parentOffsetWidth = parentEl.offsetWidth;
            var ratio = parentOffsetWidth / elOffsetWidth;
            timeout = setTimeout(anime.set(el, {scale: ratio}), 10);
          }
          resize();
          window.addEventListener('resize', resize);
        }
        
        var layeredAnimation = (function() {
        
          var transformEls = document.querySelectorAll('.transform-progress');
          var layeredAnimationEl = document.querySelector('.layered-animations');
          var shapeEls = layeredAnimationEl.querySelectorAll('.shape');
          var triangleEl = layeredAnimationEl.querySelector('polygon');
          var trianglePoints = triangleEl.getAttribute('points').split(' ');
          var easings = ['easeInOutQuad', 'easeInOutCirc', 'easeInOutSine', 'spring'];
        
          fitElementToParent(layeredAnimationEl);
        
          function createKeyframes(value) {
            var keyframes = [];
            for (var i = 0; i < 30; i++) keyframes.push({ value: value });
            return keyframes;
          }
        
          function animateShape(el) {
        
            var circleEl = el.querySelector('circle');
            var rectEl = el.querySelector('rect');
            var polyEl = el.querySelector('polygon');
        
            var animation = anime.timeline({
              targets: el,
              duration: function() { return anime.random(600, 2200); },
              easing: function() { return easings[anime.random(0, easings.length - 1)]; },
              complete: function(anim) { animateShape(anim.animatables[0].target); },
            })
            .add({
              translateX: createKeyframes(function(el) { 
                return el.classList.contains('large') ? anime.random(-300, 300) : anime.random(-520, 520);
              }),
              translateY: createKeyframes(function(el) { 
                return el.classList.contains('large') ? anime.random(-110, 110) : anime.random(-280, 280);
              }),
              rotate: createKeyframes(function() { return anime.random(-180, 180); }),
            }, 0);
            if (circleEl) {
              animation.add({
                targets: circleEl,
                r: createKeyframes(function() { return anime.random(32, 72); }),
              }, 0);
            }
            if (rectEl) {
              animation.add({
                targets: rectEl,
                width: createKeyframes(function() { return anime.random(64, 120); }),
                height: createKeyframes(function() { return anime.random(64, 120); }),
              }, 0);
            }
            if (polyEl) {
              animation.add({
                targets: polyEl,
                points: createKeyframes(function() { 
                  var scale = anime.random(72, 180) / 100;
                  return trianglePoints.map(function(p) { return p * scale; }).join(' ');
                }),
              }, 0);
            }
        
          }
        
          for (var i = 0; i < shapeEls.length; i++) {
            animateShape(shapeEls[i]);
          }
        
        })();
    </script>
</body>

</html>