<header class="bg-white">
		<!-- navigation -->
		<div class="main-top py-1">
			<nav class="navbar navbar-expand-lg navbar-light fixed-navi" style="padding: 0px;">
				<div class="container-fluid">
					<!-- logo -->
					<a class="navbar-brand font-weight-bold" href="index.php">
					    <img src="images/main-logo.webp" style="height: 65px; width: 94px;">
					</a>
					<!-- //logo -->
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
					 aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
						<ul class="navbar-nav ml-lg-auto">
							<li class="nav-item mx-xl-3 mx-lg-3 my-lg-0 my-3">
								<a class="nav-link" href="about.php">About Us</a>
							</li>
							<li class="nav-item mx-xl-2 mx-lg-3 my-lg-0 my-3">
								<a class="nav-link" href="led-lighting-system.php">LED Lighting System</a>
							</li>
							<li class="nav-item mx-xl-2 mx-lg-3 my-lg-0 my-3">
								<a class="nav-link" href="sanitising-stations.php">Sanitising Station</a>
							</li>
							<li class="nav-item mx-xl-2 mx-lg-3 my-lg-0 my-3">
								<a class="nav-link" href="AquasysLightMirror.php">Aquasys Light Mirror</a>
							</li>
							<li class="ml-lg-2 mb-lg-0 mb-4">
								<a class="nav-link" href="contact.php">Contact Us</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</div>
		<!-- //navigation -->
	</header>