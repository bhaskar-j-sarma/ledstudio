<?php
	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile = $_POST['mobile'];
	//$subject = $_POST['subject'];
	$message = $_POST['message'];	
	$to = "info@ledstudio.in, deepjyotighosh99@gmail.com, vikramshroff9@gmail.com, jitumanib07@gmail.com";
	$subject = "One new LED STUDIO contact enquiry";
	$txt = "FNAME : ".$name.",\r\nSUBJECT : ".$subject.",\r\nEMAIL : ".$email.",\r\nPHONE : ".$mobile.",\r\nMESSAGE : ".$message."";
	$headers = "From: deepjyotighosh99@gmail.com";
	mail($to,$subject,$txt,$headers);
	echo "1";
?>