<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Led Studio-Sanitising Station</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Inside Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext"
	 rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	 rel="stylesheet">
	<!-- //Web-Fonts -->
</head>
<style>
.bold {
	font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
}
</style>
<body>
	<!-- header -->
	<?php include 'header.php'; ?>
	<!-- //header -->

	<!-- banner -->
	<div class="banner-w3ls-2">

	</div>
	<!-- //banner -->
	<!-- page details -->
	<div class="breadcrumb-agile">
		<ol class="breadcrumb" style="border-radius:0;">
			<li class="breadcrumb-item">
				<a href="index.html">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">Sanitising Station</li>
		</ol>
	</div>
	<!-- //page details -->

	<!-- about section -->
	<div class="inner-sec-w3ls py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-6 about-img">
					<img class="img-fluid" src="images/sanitising-system.jpg" alt="">
				</div>
				<div class="col-lg-6 about-right">
					<h2 class="sub-tittle text-uppercase font-weight-bold">Product Details</h2>
					<h1 class="tittle mt-2 text-white">Sanitising Station</h1>
                    <p class="mt-4 mb-2 text-white">Amidst the general sentiment of cautiousness and restraint, concepts of hygiene and cleanliness are gaining prominence, and products and fittings that aid and promote these concepts holistically are now becoming extremely popular.</p>
                    <p class="text-white">Häfele brings to you its Stay Healthy Range which includes<span class="bold"> Sensor-operated Sanitising Stations for Countertops</span> as well as<span class="bold"> Wall Mounted and Floor-Standing Stations (with / without Anti-bacterial Wipes and Bin)</span>. It also includes an easy-to-use, <span class="bold"> mechanically operated model – The Foot Pedal Sanitising Station</span>. These Sanitising Stations allow preventative hygiene and protection against cross-contamination, harmful microbes and infectious viruses on surfaces. Moreover they provide complete placement flexibility in different application areas across a host of interior and exterior spaces and ensure 360° personal hygiene for you, your employees and most importantly your customers. </p>
                    
                </div>
                <div class="col-md-12">
                    <p class="mt-2 mb-2 text-white">The Laser welded, Stainless Steel body of the ‘Made in India’ Sanitising Stations provides sturdiness to the overall structure and bestows a premium finish that can easily complement any interior set-up. All sanitising stations falling under the Stay Healthy Range come equipped with a slot for discharging the liquid disinfectant while the Floor Standing Stations within the range additionally include a slot for distributing surface sanitising wipes. Both, the liquid disinfectant and the surface sanitising wipes offered by Häfele are of the highest quality and are procured from GMP approved sources selected after rigorous quality checks and audit.</p>
                </div>
            </div>
            <div class="text-center">
				<a href="contact.php" class="btn button-style mt-sm-5 mt-4">Enquiry</a>
				<a target="_blank" href="https://www.hafeleindia.com/hap-live/web/WFS/Haefele-HIN-Site/en_IN/-/INR/Static-View/pdfcatalog/en_IN/COVIDRangeBrochure/index.html?startpage=0.1#page_0.1" class="btn button-style mt-sm-5 mt-4">View Brochure</a>

            </div>


		</div>
	</div>
	<div class="blog-w3ls py-5 bg-light border-bottom" id="what">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3 mb-sm-5 mb-4 text-dark text-center font-weight-bold">LED Lighting Products</h3>
			
			<div class="row package-grids">
				<div class="col-md-6 blog-w3">
					<div class="blogs-top">
						<img src="images/bg.jpg" alt="" class="img-fluid" />
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark font-weight-bold mb-3">LOOX 5</h4>
						<p style="font-size: 20px;">The LED Lighting System</p>
						<p>for Furniture and rooms</p>
						<a target="_blank" href="https://www.hafeleindia.com/hap-live/web/WFS/Haefele-HIN-Site/en_IN/-/INR/Static-View/pdfcatalog/en_IN/Loox2020/index.html?startpage=0.1#page_0.1">
							<i class="fa fa-download mr-2"></i>Download Catalogue
						</a>
					</div>
				</div>
				<div class="col-md-6 blog-w3 my-md-0 my-5">
					<div class="blogs-top">
						<img src="images/2019stripLight.jpg" alt="" class="img-fluid" />
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark font-weight-bold mb-3">LOOX 5</h4>
						<p style="font-size: 20px;">The LED Lighting System</p>
						<p>for Furniture and rooms (Strip Lights)</p>
						<a target="_blank" href="https://www.hafeleindia.com/hap-live/web/WFS/Haefele-HIN-Site/en_IN/-/INR/Static-View/pdfcatalog/en_IN/Loox5StriplightsLeaflet2020/index.html?startpage=0.1#page_0.1">
							<i class="fa fa-download mr-2"></i>Download Catalogue
						</a>
					</div>
				</div>
			</div>
		</div
	<!-- //about section -->

<!-- Modal Form-->
<div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
  <div class="modal-content">
	<div class="modal-header">
		<h1 class="mb-4 text-capitalize text-dark">Enquiry Form</h1>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	  </button>
	</div>
	<div class="modal-body">
		<div class="contact-top1">
			<form action="#" method="get" class="contact-wthree">
				<div class="form-group d-flex">
					<label>
						<i class="fa fa-user" aria-hidden="true"></i>
					</label>
					<input class="form-control" type="name" id="name" placeholder="Enter your name..." name="name" required="">
				</div>
				<div class="form-group d-flex">
					<label>
						<i class="fa fa-envelope" aria-hidden="true"></i>
					</label>
					<input class="form-control" type="email" id="email" placeholder="Enter your email..." name="email" required="">
				</div>
				<div class="form-group d-flex">
					<label>
						<i class="fa fa-phone" aria-hidden="true"></i>
					</label>
					<input class="form-control" type="number" id="mobile" placeholder="Enter your Phone Number..." name="mobile" required="">
				</div>
				<div class="form-group d-flex">
					<label>
						<i class="fa fa-edit"></i>
					</label>
					<input class="form-control" type="text" id="subject" placeholder="Subject" name="subject" required="">
				</div>
				<div class="form-group">
					<textarea class="form-control" rows="5" id="message" placeholder="Your message" name="message" required></textarea>
				</div>
				<div class="d-flex  justify-content-end">
					<button type="submit" id="send_mail" class="btn text-white btn-block w-25">Submit</button>
				</div>
			</form>
		</div>
	</div>
	
  </div>
</div>
</div>

   



<!-- Modal Form-->
	

	<!-- footer -->
	<?php include 'footer.php'; ?>
	<!-- //footer -->


	<!-- Js files -->
	<!-- JavaScript -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- Default-JavaScript-File -->
	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!-- fixed navigation -->
	<script src="js/fixed-nav.js"></script>
	<!-- //fixed navigation -->
	<!-- dropdown smooth -->
	<script>
		$(document).ready(function () {
				$(".dropdown").hover(
					function () {
						$('.dropdown-menu', this).stop(true, true).slideDown("fast");
						$(this).toggleClass('open');
					},
					function () {
						$('.dropdown-menu', this).stop(true, true).slideUp("fast");
						$(this).toggleClass('open');
					}
				);
			});
		</script>
	<!-- //dropdown smooth -->

	<!-- search plugin -->
	<!-- pop-up-box -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/jquery.magnific-popup.js"></script>
	<!-- //pop-up-box -->
	<!-- search script -->
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

	<script>
		$(document).ready(function(){
			$("#send_mail").click(function(){
				var name=$("#name").val();
				var email=$("email").val();
				var mobile=$("#mobile").val();
				var subject=$("#subject").val();
				var message=$("#message").val();
				if(name == '' || email == '' || mobile == '' || subject == '' || message == '') 
				{  
					swal("Oops!","Please fill the menditory filled.","error");
				}
				else{
					$.ajax({
						url:'send_mail.php',
						method:'POST',
						data:{
							name:name,
							email:email,
							mobile:mobile,
							subject:subject,
							message:message
						},
						success:function(data){
							if(data == 1){
								swal("Done!","Our marketing executive contact you soon.","success");
							}else{
								swal("Sorry!","Your message not send","error");
								}
							}
					});
				}
			});
		});
	</script>
	<!-- //search script -->
	<!-- //search plugin -->

	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- move-top -->
	<script src="js/move-top.js"></script>
	<!-- easing -->
	<script src="js/easing.js"></script>
	<!--  necessary snippets for few javascript files -->
	<script src="js/inside.js"></script>

	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //Js files -->


</body>

</html>