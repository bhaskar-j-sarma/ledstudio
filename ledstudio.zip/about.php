<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Led Studio -  About Us</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Inside Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css?vs=2" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext"
	 rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	 rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- header -->
	<?php include 'header.php'; ?>
	<!-- //header -->

	<!-- banner -->
	<div class="banner-w3ls-2">

	</div>
	<!-- //banner -->
	<!-- page details -->
	<div class="breadcrumb-agile">
		<ol class="breadcrumb" style="border-radius:0;">
			<li class="breadcrumb-item">
				<a href="index.html">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">About Us</li>
		</ol>
	</div>
	<!-- //page details -->

	<!-- about section -->
	<div class="inner-sec-w3ls py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3 mb-sm-5 mb-4 text-white text-center font-weight-bold">About Us</h3>
			<div class="row">
				<div class="col-lg-6 about-img">
					<img class="img-fluid" src="images/hafelel-ed-logo-image.jpg" alt="">
				</div>
				<div class="col-lg-6 about-right mt-3">					
					<p class="text-white mt-3">'LED STUDIO is the largest H'A'FELE distributor & prime Stockist in the entire North East & Eastern India. We deal with 'HAFELE Lightings' , 'LOOX5' , 'AQUASYS LIGHT MIRROR' & 'SANITIZATION'.</p>
					<div class="row mt-3">
					    <div class="col-md-1"></div>
					    <div class="col text-center">
					        <img src="images/client.png" style="max-width:42%;">
					        <br><br>
					        <a class="contact-us mt-3" href="contact.php">Contact Us</a>
					    </div>
					    <div class="col text-center">
					        <img src="images/24h.png" style="max-width:42%;">
					        <br><br>
					        <a class="contact-us mt-3" href="tel: 8822720012">Call Now</a>
					    </div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="blog-w3ls bg-light border-bottom" id="what">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3 mb-sm-5 mb-4 text-dark text-center font-weight-bold">Our Products</h3>
			<div class="row package-grids">
				<div class="col-md-4 blog-w3">
					<div class="blogs-top">
						<img src="images/light-mirror.webp" alt="" class="img-fluid" style="width:100%; height:197px;">
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark font-weight-bold mb-3">Aquasys Light Mirror</h4>
						<a target="blank" href="https://www.hafeleindia.com/en/info/products/lighting/aquasys-light-mirror/91303/">
							<i class="fa fa-info mr-2"></i>Read More
						</a>
						<a target="blank" href="https://www.hafeleindia.com/hap-live/web/WFS/Haefele-HIN-Site/en_IN/-/INR/Static-View/pdfcatalog/en_IN/AquasysLightMirrorLeaflet2020/index.html?startpage=0.1#page_0.1">
							<i class="fa fa-download mr-2"></i>Download Catalogue
						</a>
					</div>
				</div>
				<div class="col-md-4 blog-w3 my-md-0 my-5">
					<div class="blogs-top">
						<img src="images/bg.jpg" alt="" class="img-fluid" />
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark font-weight-bold mb-3">LED Lighting System</h4>
						<a target="_blank" href="https://www.hafeleindia.com/en/info/products/lighting/5338/">
							<i class="fa fa-info mr-2"></i>Read More</a>
						<a target="blank" href="https://www.hafeleindia.com/hap-live/web/WFS/Haefele-HIN-Site/en_IN/-/INR/Static-View/pdfcatalog/en_IN/Loox2020/index.html?startpage=0.1#page_0.1">
							<i class="fa fa-download mr-2"></i>Download Catalogue
						</a>
					</div>
				</div>
				<div class="col-md-4 blog-w3">
					<div class="blogs-top">
						<img src="images/sanitising.jpg" alt="" class="img-fluid" />
					</div>
					<div class="blogs-bottom p-4 bg-white">
						<h4 class="text-dark font-weight-bold mb-3">Sanitising Station</h4>
						<a target="_blank" href="https://www.hafeleindia.com/en/info/products/sanitising-stations/107063/">
							<i class="fa fa-info mr-2"></i>Read More</a>
						<a target="blank" href="https://www.hafeleindia.com/hap-live/web/WFS/Haefele-HIN-Site/en_IN/-/INR/Static-View/pdfcatalog/en_IN/COVIDRangeBrochure/index.html?startpage=0.1#page_0.1">
							<i class="fa fa-download mr-2"></i>Download Catalogue
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- //about bottom -->

	

	<!-- footer -->
	<?php include 'footer.php'; ?>
	<!-- //footer -->


	<!-- Js files -->
	<!-- JavaScript -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- Default-JavaScript-File -->
	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!-- fixed navigation -->
	<script src="js/fixed-nav.js"></script>
	<!-- //fixed navigation -->
	<!-- dropdown smooth -->
	<script>
		$(document).ready(function () {
				$(".dropdown").hover(
					function () {
						$('.dropdown-menu', this).stop(true, true).slideDown("fast");
						$(this).toggleClass('open');
					},
					function () {
						$('.dropdown-menu', this).stop(true, true).slideUp("fast");
						$(this).toggleClass('open');
					}
				);
			});
		</script>
	<!-- //dropdown smooth -->

	<!-- search plugin -->
	<!-- pop-up-box -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/jquery.magnific-popup.js"></script>
	<!-- //pop-up-box -->
	<!-- search script -->
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
	<!-- //search script -->
	<!-- //search plugin -->

	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- move-top -->
	<script src="js/move-top.js"></script>
	<!-- easing -->
	<script src="js/easing.js"></script>
	<!--  necessary snippets for few javascript files -->
	<script src="js/inside.js"></script>

	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //Js files -->


</body>

</html>