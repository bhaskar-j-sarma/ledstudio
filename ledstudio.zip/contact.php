<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Led Studio - Contact</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Inside Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext"
	 rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	 rel="stylesheet">
	<!-- //Web-Fonts -->
</head>

<body>
	<!-- header -->
	<?php include 'header.php'; ?>
	<!-- //header -->

	<!-- banner -->
	<div class="banner-w3ls-2">

	</div>
	<!-- //banner -->
	<!-- page details -->
	<div class="breadcrumb-agile">
		<ol class="breadcrumb" style="border-radius:0;">
			<li class="breadcrumb-item">
				<a href="index.html">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">Contact Us</li>
		</ol>
	</div>
	<!-- //page details -->

	<!-- contact -->
	<div class="contact py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title-w3 mb-sm-5 mb-4 text-center font-weight-bold text-white">Contact Us</h3>
			<div class="row contact-form">
				<div class="col-lg-6 wthree-form-left">
					<!-- contact form -->
					<div class="contact-top1">
						<h1 class="mb-4 text-capitalize text-white">Get In Touch</h1>
						<form class="contact-wthree">
							<div class="form-group d-flex">
								<label>
									<i class="fa fa-user" aria-hidden="true"></i>
								</label>
								<input class="form-control" type="name" id="name" placeholder="Enter your name...">
							</div>
							<div class="form-group d-flex">
								<label>
									<i class="fa fa-envelope" aria-hidden="true"></i>
								</label>
								<input class="form-control" type="email" id="email" placeholder="Enter your email...">
							</div>
							<div class="form-group d-flex">
								<label>
									<i class="fa fa-phone" aria-hidden="true"></i>
								</label>
								<input class="form-control" type="number" id="mobile" placeholder="Enter your Phone Number...">
							</div>
							<div class="form-group d-flex">
								<label>
									<i class="fa fa-edit"></i>
								</label>
								<input class="form-control" type="text" id="subject" placeholder="Subject">
							</div>
							<div class="form-group">
								<textarea class="form-control" rows="5" id="message" placeholder="Your message"></textarea>
							</div>
							<div class="d-flex  justify-content-end">
								<button type="button" id="send_mail" class="btn text-white btn-block w-25">Submit</button>
							</div>
						</form>
					</div>
					<!--  //contact form -->
				</div>
				<!-- contact details -->
				<div class="col-lg-5 contact-bottom  mt-lg-3 d-flex flex-column contact-right-w3ls px-sm-0 px-2">
					<div class="fv3-contact mt-lg-5">
						<span class="fa fa-envelope mr-2"></span>
						<p>
							<a href="mailto:info@ledstudio.in" class="text-white">info@ledstudio.in</a>
						</p>
					</div>
					<div class="fv3-contact my-4">
						<span class="fa fa-phone mr-2"></span>
						<a href="tel:+91 8822720012"><p class="text-white">+91 8822720012</p></a>
					</div>
					<div class="mt-2 fv3-contact">
						<span onclick="location.href = 'https://www.facebook.com/LED.STUDIO9';" class="fa fa-facebook mr-2"></span>
						<span onclick="location.href = 'https://www.instagram.com/led_studio_guwahati/';" class="fa fa-instagram mr-2"></span>
					</div>
				</div>
			</div>
		</div>
	</div>
    <!-- //gallery -->
    <!--my section-->
    <div class="contact">
		<div class="container-fluid">
            <div class="row">
                <div class="col-lg-6" style="border:1px solid;">
                    <div class="text-center mt-3 mb-3">
                        <h3 class="mb-4 text-capitalize text-white text-left" style="text-decoration-color: #8c2332;  text-underline-position: under;font-weight:700;">Guwahati Location</h3>
                    </div>
                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57286.09626490784!2d91.73736265059559!3d26.18428107747567!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x375a59aa981e4c73%3A0xcdf42133ff740ff!2sLED%20Studio!5e0!3m2!1sen!2sin!4v1608024745796!5m2!1sen!2sin"
                         allowfullscreen=""></iframe>
                    </div>
                </div>
                <div class="col-lg-6" style="border:1px solid;">
                    <div class="text-center mt-3 mb-3">
                        <h3 class="mb-4 text-capitalize text-white text-left" style="text-decoration-color: #8c2332;  text-underline-position: under; font-weight:700;">Kolkata Location</h3>
                    </div>
                    <div class="map">
                        <iframe src="https://maps.google.com/maps?q=22.5832212,88.3806673&t=&z=13&ie=UTF8&iwloc=B&output=embed"
                         allowfullscreen=""></iframe>
                    </div>
                </div>
            </div>
        </div>
	</div>

    <!--my section end-->
	

	<!-- footer -->
<?php include 'footer.php'; ?>
	<!-- //footer -->


	<!-- Js files -->
	<!-- JavaScript -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- Default-JavaScript-File -->
	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!-- fixed navigation -->
	<script src="js/fixed-nav.js"></script>
	<!-- //fixed navigation -->
	<!-- dropdown smooth -->
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

	<script>
		$(document).ready(function () {
				$(".dropdown").hover(
					function () {
						$('.dropdown-menu', this).stop(true, true).slideDown("fast");
						$(this).toggleClass('open');
					},
					function () {
						$('.dropdown-menu', this).stop(true, true).slideUp("fast");
						$(this).toggleClass('open');
					}
				);
			});
		</script>
	<!-- //dropdown smooth -->
	<script>
		$(document).ready(function(){
			$("#send_mail").click(function(){
				var name=$("#name").val();
				var email=$("email").val();
				var mobile=$("#mobile").val();
				var subject=$("#subject").val();
				var message=$("#message").val();
				if(name == '' || email == '' || mobile == '' || subject == '' || message == '') 
				{  
					swal("Oops!","Please fill the menditory filled.","error");
				}
				else{
					$.ajax({
						url:'send_mail.php',
						method:'POST',
						data:{
							name:name,
							email:email,
							mobile:mobile,
							subject:subject,
							message:message
						},
						success:function(data){
							if(data == 1){
								swal("Done!","Our marketing executive contact you soon.","success");
							}else{
								swal("Sorry!","Your message not send","error");
								}
							}
					});
				}
			});
		});
	</script>
	<!-- search plugin -->
	<!-- pop-up-box -->
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />
	<script src="js/jquery.magnific-popup.js"></script>
	<!-- //pop-up-box -->
	<!-- search script -->
	<script>
		$(document).ready(function () {
			$('.popup-with-zoom-anim').magnificPopup({
				type: 'inline',
				fixedContentPos: false,
				fixedBgPos: true,
				overflowY: 'auto',
				closeBtnInside: true,
				preloader: false,
				midClick: true,
				removalDelay: 300,
				mainClass: 'my-mfp-zoom-in'
			});

		});
	</script>
	<!-- //search script -->
	<!-- //search plugin -->
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

	<script>
		$(document).ready(function(){
			$("#send_mail").click(function(){
				var name=$("#name").val();
				var email=$("#email").val();
				var mobile=$("#mobile").val();
				var subject=$("#subject").val();
				var message=$("#message").val();
				if(name == '' || email == '' || mobile == '' || subject == '' || message == '') 
				{  
					swal("Oops!","Please fill the menditory filled.","error");
				}
				else{
					$.ajax({
						url:'send_mail.php',
						method:'POST',
						data:{
							name:name,
							email:email,
							mobile:mobile,
							subject:subject,
							message:message
						},
						success:function(data){
							if(data == 1){
								swal("Done!","Our marketing executive contact you soon.","success");
							}else{
								swal("Sorry!","Your message not send","error");
								}
							}
					});
				}
			});
		});
	</script>

	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- move-top -->
	<script src="js/move-top.js"></script>
	<!-- easing -->
	<script src="js/easing.js"></script>
	<!--  necessary snippets for few javascript files -->
	<script src="js/inside.js"></script>

	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //Js files -->


</body>

</html>